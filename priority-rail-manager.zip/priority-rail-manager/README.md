# Priority Rail Manager

A highly responsive, modern full-stack Railway Reservation & Priority Management System. A dashboard layout with a dark-mode theme, vibrant neon highlights and clean sidebar navigation. It visually manages and reflects the underlying operations of Confirmed Bookings, a Priority Waiting List (which dynamically sorts disabled/special passengers to the front), and a real-time Cancellation Log.

The application includes the following views and structural components:

1. **Dashboard Overview**: A main panel displaying quick status counters (Total Confirmed Seats, Active Waiting Queue Count, Total Cancelled Tickets) alongside an input area to "Book Ticket". The booking form collects Passenger Name, Age, Train Number, origin and destination, and a toggle for Disabled Status.
2. **Seat Matrix & Fare Management**: Automated fare computation rules based on passenger demographics (standard price Rs.100, senior citizen discount Rs.60 for age 60+, child discount Rs.50 for age under 10). A hard limit for maximum confirmed seats (set to 3 initially for demonstration purposes) pushes subsequent bookings to a prioritized waiting queue.
3. **Live Data Queues**:
   - A grid displaying all "Confirmed Bookings" featuring a functional "Cancel Ticket" action button alongside each card.
   - A prioritized "Waiting List View" that updates dynamically in real-time, grouping disabled passengers seamlessly at the top in a first-in, first-out sequence.
   - A sequential log tracking "Cancellation History" arrayed in a last-in, first-out order.
4. **Core Interactive Logic**: When a user clicks "Cancel Ticket" on a confirmed passenger card, it immediately releases that seat, moves the passenger profile to the cancellation log, and automatically triggers an auto-promotion checking the waiting queue to elevate the highest priority passenger into the newly freed seat with full status updates. A global search field allows quick lookup of active booking files by their unique PNR number.

## Development

You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
