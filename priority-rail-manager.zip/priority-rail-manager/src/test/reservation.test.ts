import { describe, it, expect } from "vitest";
import { book, cancel, computeFare, emptyState, type State } from "@/lib/reservation";

const add = (s: State, name: string, age = 30, disabled = false) =>
  book(s, { name, age, train: "12001", disabled }).state;

describe("reservation rules", () => {
  it("keeps the travel origin and destination after cancellation and priority promotion", () => {
    let s = emptyState;
    for (const name of ["A", "B", "C"]) s = book(s, { name, age: 30, train: "12001", origin: "Dehradun", destination: "Delhi", disabled: false }).state;
    s = book(s, { name: "D", age: 30, train: "12001", origin: "Pune", destination: "Mumbai", disabled: true }).state;
    const first = s.confirmed[0];
    if (!first) throw new Error("Expected a confirmed passenger");
    const result = cancel(s, first.pnr);
    expect(result.promoted?.destination).toBe("Mumbai");
    expect(result.state.cancelled[0]?.destination).toBe("Delhi");
    expect(result.promoted?.origin).toBe("Pune");
    expect(result.state.cancelled[0]?.origin).toBe("Dehradun");
  });
  it.each([[30, 100], [60, 60], [9, 50]])("stores final fare for age %i as %i", (age, fare) => {
    const { passenger } = book(emptyState, { name: "Fare check", age, train: "12001", origin: "Delhi", destination: "Mumbai", disabled: false });
    expect(passenger.fare).toBe(fare);
  });
  it("fares: standard 100, senior 60+ is 60, child under 10 is 50", () => {
    expect(computeFare(30)).toBe(100);
    expect(computeFare(60)).toBe(60);
    expect(computeFare(9)).toBe(50);
    expect(computeFare(10)).toBe(100);
  });
  it("caps confirmed seats at 3, rest wait", () => {
    let s = emptyState;
    for (const n of ["A", "B", "C", "D"]) s = add(s, n);
    expect(s.confirmed).toHaveLength(3);
    expect(s.waiting.map((p) => p.name)).toEqual(["D"]);
  });
  it("disabled passengers go first in waiting, FIFO within groups", () => {
    let s = emptyState;
    for (const n of ["A", "B", "C", "D"]) s = add(s, n);
    s = add(s, "E", 30, true);
    s = add(s, "F", 30, true);
    expect(s.waiting.map((p) => p.name)).toEqual(["E", "F", "D"]);
  });
  it("cancel logs LIFO and promotes top waiting into freed seat", () => {
    let s = emptyState;
    for (const n of ["A", "B", "C", "D"]) s = add(s, n);
    s = add(s, "E", 30, true);
    const b = s.confirmed[1];
    if (!b) throw new Error("Expected second confirmed passenger");
    s = cancel(s, b.pnr).state;
    expect(s.confirmed.find((p) => p.name === "E")?.seat).toBe(b.seat);
    const first = s.confirmed[0];
    if (!first) throw new Error("Expected first confirmed passenger");
    s = cancel(s, first.pnr).state;
    expect(s.cancelled.map((p) => p.name)).toEqual(["A", "B"]);
    expect(s.waiting).toHaveLength(0);
  });
});
