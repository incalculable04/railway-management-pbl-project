import { createFileRoute } from "@tanstack/react-router";
import { ConfirmedGrid, PageTitle } from "@/components/rail";

export const Route = createFileRoute("/bookings")({
  head: () => ({
    meta: [
      { title: "Confirmed Bookings — RailQ" },
      { name: "description", content: "All confirmed seats with one-click cancellation and auto-promotion." },
      { property: "og:title", content: "Confirmed Bookings — RailQ" },
      { property: "og:description", content: "All confirmed seats with one-click cancellation and auto-promotion." },
    ],
  }),
  component: () => (
    <>
      <PageTitle title="Confirmed Bookings" sub="Cancelling a ticket frees the seat and promotes the next waiting passenger" />
      <ConfirmedGrid />
    </>
  ),
});
