import { createFileRoute } from "@tanstack/react-router";
import { BookingForm, ConfirmedGrid, PageTitle, Stats, WaitingList } from "@/components/rail";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "RailQ — Reservation Dashboard" },
      { name: "description", content: "Book train tickets, manage confirmed seats and the priority waiting list." },
      { property: "og:title", content: "RailQ — Reservation Dashboard" },
      { property: "og:description", content: "Book train tickets, manage confirmed seats and the priority waiting list." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <PageTitle title="Dashboard" sub="Live reservation status and booking" />
      <Stats />
      <div className="mt-6 grid gap-6 lg:grid-cols-[360px_1fr]">
        <BookingForm />
        <div className="space-y-6">
          <section>
            <h2 className="mb-3 font-semibold">Confirmed Bookings</h2>
            <ConfirmedGrid />
          </section>
          <section>
            <h2 className="mb-3 font-semibold">Priority Waiting List</h2>
            <WaitingList />
          </section>
        </div>
      </div>
    </>
  );
}
