import { useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { LayoutDashboard, Ticket, Hourglass, History, Search, TrainFront, Accessibility, X } from "lucide-react";
import {
  book,
  cancel,
  computeFare,
  findByPnr,
  getState,
  setState,
  useReservations,
  MAX_SEATS,
  type Passenger,
} from "@/lib/reservation";

const nav = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/bookings", label: "Confirmed", icon: Ticket },
  { to: "/waiting", label: "Waiting List", icon: Hourglass },
  { to: "/cancellations", label: "Cancellations", icon: History },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      <aside className="border-b border-sidebar-border bg-sidebar md:sticky md:top-0 md:h-screen md:w-60 md:border-b-0 md:border-r">
        <div className="flex items-center gap-2 px-5 py-5">
          <TrainFront className="h-6 w-6 text-primary drop-shadow-[0_0_8px_var(--primary)]" />
          <span className="text-lg font-bold tracking-tight">RailQ</span>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-3 pb-3 md:flex-col">
          {nav.map(({ to, label, icon: Icon }) => (
            <Link
              key={to}
              to={to}
              activeOptions={{ exact: true }}
              className="flex items-center gap-3 whitespace-nowrap rounded-lg px-3 py-2 text-sm text-muted-foreground transition hover:bg-sidebar-accent hover:text-foreground"
              activeProps={{ className: "bg-sidebar-accent text-primary shadow-glow" }}
            >
              <Icon className="h-4 w-4" /> {label}
            </Link>
          ))}
        </nav>
      </aside>
      <main className="min-w-0 flex-1 p-4 md:p-8">
        <PnrSearch />
        <div className="mt-6">{children}</div>
      </main>
    </div>
  );
}

function PnrSearch() {
  const s = useReservations();
  const [q, setQ] = useState("");
  const hit = findByPnr(s, q);
  return (
    <div className="relative max-w-md">
      <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search by PNR number…"
        className="w-full rounded-lg border border-input bg-card py-2 pl-9 pr-3 font-mono text-sm outline-none focus:border-primary focus:shadow-glow"
      />
      {q.trim() && (
        <div className="absolute z-10 mt-2 w-full rounded-lg border border-border bg-popover p-3 shadow-xl">
          {hit ? <PassengerCard p={hit} /> : <p className="text-sm text-muted-foreground">No booking found for “{q}”.</p>}
        </div>
      )}
    </div>
  );
}

const statusStyle: Record<Passenger["status"], string> = {
  CONFIRMED: "text-primary border-primary/50",
  WAITING: "text-warning border-warning/50",
  CANCELLED: "text-destructive border-destructive/50",
};

export function PassengerCard({ p, action, index }: { p: Passenger; action?: ReactNode; index?: number }) {
  return (
    <div className="flex flex-col gap-3 rounded-xl border border-border bg-card p-4 transition hover:border-primary/40">
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-2">
          {index !== undefined && <span className="font-mono text-xs text-muted-foreground">#{index + 1}</span>}
          <span className="truncate font-semibold">{p.name}</span>
          {p.disabled && (
            <span className="inline-flex items-center gap-1 rounded-full bg-accent/20 px-2 py-0.5 text-xs text-accent">
              <Accessibility className="h-3 w-3" /> Priority
            </span>
          )}
          {p.promoted && p.status === "CONFIRMED" && (
            <span className="rounded-full bg-primary/15 px-2 py-0.5 text-xs text-primary">Promoted</span>
          )}
        </div>
        <div className="mt-1 font-mono text-xs text-muted-foreground">
          {p.pnr} · Train {p.train} · Age {p.age}
          {p.seat ? ` · Seat ${p.seat}` : ""}
        </div>
        {p.origin && <div className="mt-2 break-words text-sm text-foreground">From: {p.origin}</div>}
        {p.destination && <div className="mt-1 break-words text-sm text-foreground">Destination: {p.destination}</div>}
        <div className="mt-2 text-sm text-primary">Final fare: <span className="font-mono font-semibold">Rs.{p.fare}</span></div>
        <span className={`mt-2 inline-block rounded border px-1.5 py-0.5 font-mono text-[10px] ${statusStyle[p.status]}`}>
          {p.status}
        </span>
      </div>
      {action}
    </div>
  );
}

export function CancelButton({ pnr }: { pnr: string }) {
  return (
    <Button variant="outline" size="sm"
      onClick={() => {
        const { state, promoted } = cancel(getState(), pnr);
        setState(state);
        toast.success(`Ticket ${pnr} cancelled`, {
          description: promoted ? `${promoted.name} promoted to seat ${promoted.seat}` : "Seat released",
        });
      }}
      className="inline-flex w-fit shrink-0 items-center gap-1 rounded-lg border border-destructive/50 px-3 py-1.5 text-xs font-medium text-destructive transition hover:bg-destructive hover:text-destructive-foreground"
    >
      <X className="h-3 w-3" /> Cancel Ticket
    </Button>
  );
}

export function PageTitle({ title, sub }: { title: string; sub: string }) {
  return (
    <div className="mb-6">
      <h1 className="text-2xl font-bold tracking-tight md:text-3xl">{title}</h1>
      <p className="text-sm text-muted-foreground">{sub}</p>
    </div>
  );
}

export function Empty({ text }: { text: string }) {
  return <div className="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">{text}</div>;
}

export function ConfirmedGrid() {
  const s = useReservations();
  if (!s.confirmed.length) return <Empty text="No confirmed bookings yet." />;
  return (
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
      {[...s.confirmed].sort((a, b) => (a.seat ?? 0) - (b.seat ?? 0)).map((p) => (
        <PassengerCard key={p.pnr} p={p} action={<CancelButton pnr={p.pnr} />} />
      ))}
    </div>
  );
}

export function WaitingList() {
  const s = useReservations();
  if (!s.waiting.length) return <Empty text="Waiting queue is empty." />;
  return (
    <div className="space-y-2">
      {s.waiting.map((p, i) => <PassengerCard key={p.pnr} p={p} index={i} />)}
    </div>
  );
}

export function CancellationLog() {
  const s = useReservations();
  if (!s.cancelled.length) return <Empty text="No cancellations recorded." />;
  return (
    <ol className="space-y-2 border-l border-destructive/40 pl-4">
      {s.cancelled.map((p) => (
        <li key={p.pnr + p.cancelledAt}>
          <div className="mb-1 font-mono text-xs text-muted-foreground">{p.cancelledAt !== undefined ? new Date(p.cancelledAt).toLocaleString() : ""}</div>
          <PassengerCard p={p} />
        </li>
      ))}
    </ol>
  );
}

export function Stats() {
  const s = useReservations();
  const items = [
    { label: "Confirmed Seats", value: `${s.confirmed.length}/${MAX_SEATS}`, cls: "text-primary shadow-glow" },
    { label: "Waiting Queue", value: s.waiting.length, cls: "text-warning" },
    { label: "Cancelled Tickets", value: s.cancelled.length, cls: "text-accent shadow-glow-accent" },
  ];
  return (
    <div className="grid gap-3 sm:grid-cols-3">
      {items.map((it) => (
        <div key={it.label} className="rounded-xl border border-border bg-card p-5">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">{it.label}</div>
          <div className={`mt-2 inline-block rounded-md font-mono text-4xl font-bold ${it.cls.split(" ")[0]}`}>{it.value}</div>
        </div>
      ))}
    </div>
  );
}

export function BookingForm() {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [train, setTrain] = useState("");
  const [destination, setDestination] = useState("");
  const [origin, setOrigin] = useState("");
  const [disabled, setDisabled] = useState(false);
  const ageN = Number(age);
  const field = "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:border-primary";
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (!name.trim() || !train.trim() || !origin.trim() || !destination.trim() || !age || ageN < 0 || ageN > 120) { toast.error("Please fill all fields correctly"); return; }
        const { state, passenger } = book(getState(), { name: name.trim(), age: ageN, train: train.trim(), origin: origin.trim(), destination: destination.trim(), disabled });
        setState(state);
        toast.success(passenger.status === "CONFIRMED" ? `Confirmed! Seat ${passenger.seat}` : "Added to waiting list", {
          description: `PNR ${passenger.pnr} · ${passenger.origin} → ${passenger.destination} · Rs.${passenger.fare}`,
        });
        setName(""); setAge(""); setTrain(""); setOrigin(""); setDestination(""); setDisabled(false);
      }}
      className="space-y-4 rounded-xl border border-primary/30 bg-card p-5 shadow-glow"
    >
      <h2 className="font-semibold">Book Ticket</h2>
      <input className={field} aria-label="Passenger name" required placeholder="Passenger name" value={name} onChange={(e) => setName(e.target.value)} />
      <div className="grid grid-cols-2 gap-3">
        <input className={field} type="number" aria-label="Age" required min={0} max={120} placeholder="Age" value={age} onChange={(e) => setAge(e.target.value)} />
        <input className={field} aria-label="Train number" required placeholder="Train no." value={train} onChange={(e) => setTrain(e.target.value)} />
      </div>
      <div className="space-y-1.5">
        <label htmlFor="origin" className="text-sm font-medium">Travel origin</label>
        <input id="origin" className={field} required placeholder="Departure city or station" value={origin} onChange={(e) => setOrigin(e.target.value)} />
      </div>
      <div className="space-y-1.5">
        <label htmlFor="destination" className="text-sm font-medium">Travel destination</label>
        <input id="destination" className={field} required placeholder="Destination city or station" value={destination} onChange={(e) => setDestination(e.target.value)} />
      </div>
      <label className="flex cursor-pointer items-center justify-between rounded-lg border border-input px-3 py-2 text-sm">
        <span className="flex items-center gap-2"><Accessibility className="h-4 w-4 text-accent" /> Disabled / special passenger</span>
        <Switch aria-label="Disabled / special passenger" checked={disabled} onCheckedChange={setDisabled} />
      </label>
      <div className="flex items-center justify-between gap-3 border-t border-border pt-3 text-sm">
        <div>
          <div className="font-medium">Final ticket fare</div>
          {age && ageN >= 0 && ageN <= 120 && <div className="text-xs text-muted-foreground">{ageN >= 60 ? "Senior" : ageN < 10 ? "Child" : "Standard"}</div>}
        </div>
        <output aria-label="Final ticket fare" aria-live="polite" className="font-mono text-lg font-semibold text-primary">{age && ageN >= 0 && ageN <= 120 ? `Rs.${computeFare(ageN)}` : "—"}</output>
      </div>
      <Button type="submit" className="w-full" size="lg">
        Book Now
      </Button>
    </form>
  );
}
