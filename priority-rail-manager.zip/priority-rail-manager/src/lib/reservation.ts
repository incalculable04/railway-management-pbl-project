import { useSyncExternalStore } from "react";

export const MAX_SEATS = 3;

export type Status = "CONFIRMED" | "WAITING" | "CANCELLED";
export interface Passenger {
  pnr: string;
  name: string;
  age: number;
  train: string;
  destination?: string;
  origin?: string;
  disabled: boolean;
  fare: number;
  status: Status;
  seat?: number | undefined;
  createdAt: number;
  seq: number;
  cancelledAt?: number;
  promoted?: boolean;
}
export interface State {
  confirmed: Passenger[];
  waiting: Passenger[]; // kept priority-sorted
  cancelled: Passenger[]; // LIFO: newest first
  seq: number;
}

export function computeFare(age: number): number {
  if (age >= 60) return 60;
  if (age < 10) return 50;
  return 100;
}

export function sortWaiting(list: Passenger[]): Passenger[] {
  return [...list].sort((a, b) => Number(b.disabled) - Number(a.disabled) || a.seq - b.seq);
}

function freeSeat(confirmed: Passenger[]): number {
  for (let i = 1; i <= MAX_SEATS; i++) if (!confirmed.some((p) => p.seat === i)) return i;
  return -1;
}

export const emptyState: State = { confirmed: [], waiting: [], cancelled: [], seq: 0 };

export function book(
  s: State,
  input: { name: string; age: number; train: string; origin?: string; destination?: string; disabled: boolean },
  now = Date.now(),
): { state: State; passenger: Passenger } {
  const seq = s.seq + 1;
  const base: Passenger = {
    ...input,
    pnr: `PNR${String(4000 + seq)}${Math.floor(now % 97).toString().padStart(2, "0")}`,
    fare: computeFare(input.age),
    status: "WAITING",
    createdAt: now,
    seq,
  };
  if (s.confirmed.length < MAX_SEATS) {
    const p = { ...base, status: "CONFIRMED" as const, seat: freeSeat(s.confirmed) };
    return { state: { ...s, seq, confirmed: [...s.confirmed, p] }, passenger: p };
  }
  return { state: { ...s, seq, waiting: sortWaiting([...s.waiting, base]) }, passenger: base };
}

export function cancel(s: State, pnr: string, now = Date.now()): { state: State; promoted?: Passenger | undefined } {
  const target = s.confirmed.find((p) => p.pnr === pnr);
  if (!target) return { state: s };
  let confirmed = s.confirmed.filter((p) => p.pnr !== pnr);
  const cancelled = [{ ...target, status: "CANCELLED" as const, cancelledAt: now }, ...s.cancelled];
  let waiting = s.waiting;
  let promoted: Passenger | undefined;
  const [head, ...rest] = waiting;
  if (head) {
    promoted = { ...head, status: "CONFIRMED", promoted: true };
    if (target.seat !== undefined) promoted.seat = target.seat;
    confirmed = [...confirmed, promoted];
    waiting = rest;
  }
  return { state: { ...s, confirmed, waiting, cancelled }, promoted };
}

export function findByPnr(s: State, pnr: string): Passenger | undefined {
  const q = pnr.trim().toUpperCase();
  if (!q) return;
  return [...s.confirmed, ...s.waiting, ...s.cancelled].find((p) => p.pnr.toUpperCase() === q);
}

// ---- store ----
const KEY = "rail-res-state-v1";
let state: State = emptyState;
let loaded = false;
const listeners = new Set<() => void>();
function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) state = JSON.parse(raw);
  } catch {}
}
export function setState(next: State) {
  state = next;
  if (typeof window !== "undefined") localStorage.setItem(KEY, JSON.stringify(state));
  listeners.forEach((l) => l());
}
export function getState() {
  load();
  return state;
}
export function useReservations(): State {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      if (!loaded) {
        load();
        l();
      }
      return () => listeners.delete(l);
    },
    getState,
    () => emptyState,
  );
}
