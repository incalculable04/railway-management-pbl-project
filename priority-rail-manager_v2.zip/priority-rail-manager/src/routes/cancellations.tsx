import { createFileRoute } from "@tanstack/react-router";
import { CancellationLog, PageTitle } from "@/components/rail";

export const Route = createFileRoute("/cancellations")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Cancellation History — RailQ" },
      { name: "description", content: "Log of cancelled tickets, most recent first." },
      { property: "og:title", content: "Cancellation History — RailQ" },
      { property: "og:description", content: "Log of cancelled tickets, most recent first." },
    ],
  }),
  component: () => (
    <>
      <PageTitle title="Cancellation History" sub="Most recent cancellation first" />
      <CancellationLog />
    </>
  ),
});
