import { createFileRoute } from "@tanstack/react-router";
import { BookingForm, ConfirmedGrid, PageTitle, Stats, WaitingList, SeatOverview } from "@/components/rail";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "RailQ — Reservation Dashboard" },
      { name: "description", content: "Book train tickets, manage confirmed seats and the priority waiting list." },
      { property: "og:title", content: "RailQ — Reservation Dashboard" },
      { property: "og:description", content: "Book train tickets, manage confirmed seats and the priority waiting list." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <PageTitle title="Reservation overview" sub="" />
      <Stats />
      <SeatOverview />
      <div className="grid items-start gap-6 lg:grid-cols-[340px_minmax(0,1fr)]">
        <BookingForm />
        <div className="space-y-6">
          <section>
            <h2 className="mb-4 text-sm font-semibold">Confirmed Bookings</h2>
            <ConfirmedGrid />
          </section>
          <section>
            <h2 className="mb-4 text-sm font-semibold">Priority Waiting List</h2>
            <WaitingList />
          </section>
        </div>
      </div>
    </>
  );
}
