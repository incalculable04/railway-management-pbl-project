import { createFileRoute } from "@tanstack/react-router";
import { ConfirmedGrid, PageTitle } from "@/components/rail";

export const Route = createFileRoute("/bookings")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Confirmed Bookings — RailQ" },
      { name: "description", content: "All confirmed seats with one-click cancellation and auto-promotion." },
      { property: "og:title", content: "Confirmed Bookings — RailQ" },
      { property: "og:description", content: "All confirmed seats with one-click cancellation and auto-promotion." },
    ],
  }),
  component: () => (
    <>
      <PageTitle title="Confirmed Bookings" sub="All reserved seats and passenger journeys." />
      <ConfirmedGrid />
    </>
  ),
});
