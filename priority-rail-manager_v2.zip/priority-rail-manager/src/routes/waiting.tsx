import { createFileRoute } from "@tanstack/react-router";
import { PageTitle, WaitingList } from "@/components/rail";

export const Route = createFileRoute("/waiting")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Priority Waiting List — RailQ" },
      { name: "description", content: "Waiting queue with disabled passengers prioritised, first-in first-out." },
      { property: "og:title", content: "Priority Waiting List — RailQ" },
      { property: "og:description", content: "Waiting queue with disabled passengers prioritised, first-in first-out." },
    ],
  }),
  component: () => (
    <>
      <PageTitle title="Priority Waiting List" sub="Passengers awaiting a seat, ordered by priority." />
      <WaitingList />
    </>
  ),
});
