import { useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { LayoutDashboard, Ticket, Hourglass, History, Search, TrainFront, Accessibility, X, ArrowRight, MapPin, Armchair, CircleCheck, Users, ReceiptText, Plus, Route as RouteIcon } from "lucide-react";
import { book, cancel, computeFare, findByPnr, getState, setState, useReservations, MAX_SEATS, type Passenger } from "@/lib/reservation";

const nav = [
  { to: "/", label: "Overview", icon: LayoutDashboard },
  { to: "/bookings", label: "Confirmed", icon: Ticket },
  { to: "/waiting", label: "Waiting list", icon: Hourglass },
  { to: "/cancellations", label: "Cancellations", icon: History },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      <aside className="rail-sidebar border-b border-sidebar-border bg-sidebar md:sticky md:top-0 md:h-screen md:w-56 md:shrink-0 md:border-b-0 md:border-r">
        <Link to="/" className="flex items-center gap-3 px-6 py-7" aria-label="RailQ home">
          <span className="flex size-10 items-center justify-center rounded-lg bg-primary text-primary-foreground"><TrainFront className="size-6" /></span>
          <div><span className="text-xl font-bold">RailQ<span className="text-primary">.</span></span><p className="text-[11px] text-muted-foreground">Passenger management</p></div>
        </Link>
        <div className="mb-3 hidden px-6 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground md:block">Workspace</div>
        <nav className="flex gap-1 overflow-x-auto px-3 pb-4 md:flex-col md:gap-2">
          {nav.map(({ to, label, icon: Icon }) => (
            <Link key={to} to={to} activeOptions={{ exact: true }} className="flex items-center gap-3 whitespace-nowrap rounded-md px-3 py-3 text-sm font-medium text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground" activeProps={{ className: "bg-sidebar-accent text-primary" }}>
              <Icon className="size-[18px]" />{label}
            </Link>
          ))}
        </nav>
        <div className="absolute bottom-6 left-5 right-5 hidden border-t border-sidebar-border pt-5 md:block">
          <div className="flex items-center gap-2 text-xs text-muted-foreground"><span className="size-1.5 rounded-full bg-primary" /> Reservation system</div>
          <p className="mt-2 text-[10px] text-muted-foreground">Every journey starts here.</p>
        </div>
      </aside>
      <div className="min-w-0 flex-1">
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-border bg-card/40 px-5 py-4 lg:px-8">
          <span className="hidden items-center gap-2 text-xs text-muted-foreground lg:flex"><TrainFront className="size-4" /> Railway operations</span>
          <PnrSearch />
          <span className="flex items-center gap-2 text-xs text-muted-foreground"><span className="size-1.5 rounded-full bg-primary" /> Live</span>
        </header>
        <main className="mx-auto max-w-[1600px] p-5 lg:p-8">{children}</main>
      </div>
    </div>
  );
}

function PnrSearch() {
  const s = useReservations();
  const [q, setQ] = useState("");
  const hit = findByPnr(s, q);
  return (
    <div className="relative w-full max-w-sm flex-1">
      <Search className="absolute left-3 top-3 size-4 text-muted-foreground" />
      <input aria-label="Search by PNR" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search a PNR number" className="h-10 w-full rounded-md border border-input bg-background pl-10 pr-9 text-sm outline-none transition-colors focus:border-primary" />
      {q && <Button variant="ghost" size="icon" aria-label="Clear search" className="absolute right-1 top-1 size-8 text-muted-foreground" onClick={() => setQ("")}><X /></Button>}
      {q.trim() && <div className="absolute right-0 z-20 mt-2 w-full rounded-lg border border-border bg-popover p-2 shadow-glow">{hit ? <PassengerCard p={hit} /> : <p className="p-3 text-sm text-muted-foreground">No booking found for “{q}”.</p>}</div>}
    </div>
  );
}

const statusStyle: Record<Passenger["status"], string> = {
  CONFIRMED: "bg-primary/10 text-primary",
  WAITING: "bg-warning/10 text-warning",
  CANCELLED: "bg-destructive/10 text-destructive",
};

export function PassengerCard({ p, action, index }: { p: Passenger; action?: ReactNode; index?: number }) {
  return (
    <article className="ticket-card min-w-0 rounded-lg border border-border bg-card p-4 transition-colors hover:border-primary/40">
      <div className="flex items-start justify-between gap-2">
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="flex size-9 shrink-0 items-center justify-center rounded-md bg-secondary font-semibold text-muted-foreground">{index !== undefined ? String(index + 1).padStart(2, "0") : p.name.slice(0, 1).toUpperCase()}</span>
          <div className="min-w-0"><h3 className="break-words text-sm font-semibold">{p.name}</h3><p className="mt-0.5 text-[11px] text-muted-foreground">Age {p.age}{p.disabled ? " · Priority passenger" : ""}</p></div>
        </div>
        {p.disabled && <Accessibility aria-label="Priority passenger" className="size-4 shrink-0 text-accent" />}
      </div>
      <div className="my-4 flex items-start gap-2.5">
        <MapPin className="mt-0.5 size-4 shrink-0 text-primary" />
        <div className="min-w-0 text-sm"><div className="break-words font-medium">{p.origin || "Origin not recorded"}</div><div className="my-1 text-muted-foreground"><ArrowRight className="size-3.5" /></div><div className="break-words font-medium">{p.destination || "Destination not recorded"}</div></div>
      </div>
      <div className="flex flex-wrap justify-between gap-2 border-t border-dashed border-border pt-3 text-[11px] text-muted-foreground"><span className="flex items-center gap-1.5"><TrainFront className="size-3.5" /> Train {p.train}</span>{p.seat !== undefined && <span className="flex items-center gap-1.5"><Armchair className="size-3.5" /> Seat {p.seat}</span>}</div>
      <div className="mt-3 flex flex-wrap items-center justify-between gap-2"><span className={`rounded px-2 py-1 text-[10px] font-semibold ${statusStyle[p.status]}`}>{p.promoted && p.status === "CONFIRMED" ? "PROMOTED" : p.status}</span><span className="font-mono text-sm font-semibold">Rs.{p.fare}</span></div>
      <div className="mt-3 flex flex-wrap items-center justify-between gap-2"><span className="font-mono text-[10px] text-muted-foreground">{p.pnr}</span>{action}</div>
    </article>
  );
}

export function CancelButton({ pnr }: { pnr: string }) {
  return <Button variant="ghost" size="sm" className="h-7 px-2 text-[11px] text-destructive hover:bg-destructive/10 hover:text-destructive" onClick={() => {
    const { state, promoted } = cancel(getState(), pnr);
    setState(state);
    toast.success(`Ticket ${pnr} cancelled`, { description: promoted ? `${promoted.name} promoted to seat ${promoted.seat}` : "Seat released" });
  }}><X className="size-3" /> Cancel Ticket</Button>;
}

export function PageTitle({ title, sub }: { title: string; sub: string }) {
  return <div className="mb-7"><p className="mb-2 text-[10px] font-semibold uppercase tracking-widest text-primary">RailQ / Reservations</p><h1 className="text-2xl font-semibold md:text-3xl">{title}</h1><p className="mt-2 text-sm text-muted-foreground">{sub}</p></div>;
}

export function Empty({ text }: { text: string }) {
  return <div className="flex min-h-40 flex-col items-center justify-center gap-3 border-y border-dashed border-border px-4 py-7 text-center"><Ticket className="size-7 text-muted-foreground/60" /><p className="text-sm text-muted-foreground">{text}</p></div>;
}

export function ConfirmedGrid() {
  const s = useReservations();
  if (!s.confirmed.length) return <Empty text="No confirmed bookings yet." />;
  return <div className="grid gap-3 xl:grid-cols-2 2xl:grid-cols-3">{[...s.confirmed].sort((a, b) => (a.seat ?? 0) - (b.seat ?? 0)).map((p) => <PassengerCard key={p.pnr} p={p} action={<CancelButton pnr={p.pnr} />} />)}</div>;
}

export function WaitingList() {
  const s = useReservations();
  if (!s.waiting.length) return <Empty text="No passengers in the waiting list." />;
  return <div className="grid gap-3 xl:grid-cols-2 2xl:grid-cols-3">{s.waiting.map((p, i) => <PassengerCard key={p.pnr} p={p} index={i} />)}</div>;
}

export function CancellationLog() {
  const s = useReservations();
  if (!s.cancelled.length) return <Empty text="No cancellations recorded." />;
  return <ol className="space-y-5 border-l border-border pl-5">{s.cancelled.map((p) => <li key={p.pnr + p.cancelledAt}><div className="mb-2 text-xs text-muted-foreground">{p.cancelledAt !== undefined ? new Date(p.cancelledAt).toLocaleString() : ""}</div><PassengerCard p={p} /></li>)}</ol>;
}

export function Stats() {
  const s = useReservations();
  const items = [
    { label: "Confirmed seats", value: s.confirmed.length, suffix: `/ ${MAX_SEATS}`, detail: `${MAX_SEATS - s.confirmed.length} seats available`, icon: CircleCheck, cls: "text-primary bg-primary/10" },
    { label: "Waiting list", value: s.waiting.length, suffix: "", detail: `${s.waiting.filter(p => p.disabled).length} priority passengers`, icon: Users, cls: "text-warning bg-warning/10" },
    { label: "Cancelled tickets", value: s.cancelled.length, suffix: "", detail: "Reservation history", icon: ReceiptText, cls: "text-accent bg-accent/10" },
  ];
  return <div className="grid gap-3 sm:grid-cols-3">{items.map(({ label, value, suffix, detail, icon: Icon, cls }) => <div key={label} className="rounded-lg border border-border bg-card p-5"><div className="flex items-center justify-between gap-2"><span className="text-xs font-medium text-muted-foreground">{label}</span><span className={`flex size-8 shrink-0 items-center justify-center rounded-md ${cls}`}><Icon className="size-4" /></span></div><div className="mt-3 flex items-baseline gap-2"><span className="text-3xl font-semibold">{value}</span><span className="text-sm text-muted-foreground">{suffix}</span></div><p className="mt-2 text-[11px] text-muted-foreground">{detail}</p></div>)}</div>;
}

export function SeatOverview() {
  const s = useReservations();
  return <div className="my-6 flex flex-wrap items-center justify-between gap-4 border-y border-border py-4"><div className="flex items-center gap-3"><Armchair className="size-5 text-primary" /><div><h2 className="text-sm font-medium">Seat availability</h2><p className="mt-0.5 text-xs text-muted-foreground">{s.confirmed.length === MAX_SEATS ? "All seats reserved" : `${MAX_SEATS - s.confirmed.length} of ${MAX_SEATS} seats open`}</p></div></div><div className="flex gap-2">{Array.from({ length: MAX_SEATS }, (_, i) => { const occupied = s.confirmed.some(p => p.seat === i + 1); return <div key={i} title={`Seat ${i + 1}: ${occupied ? "Reserved" : "Available"}`} className={`flex h-10 w-14 items-center justify-center gap-1.5 rounded-md border text-xs ${occupied ? "border-border bg-secondary text-muted-foreground" : "border-primary/40 bg-primary/10 text-primary"}`}><Armchair className="size-4" />{i + 1}</div>; })}</div></div>;
}

export function BookingForm() {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [train, setTrain] = useState("");
  const [destination, setDestination] = useState("");
  const [origin, setOrigin] = useState("");
  const [disabled, setDisabled] = useState(false);
  const ageN = Number(age);
  const field = "mt-1.5 h-11 w-full rounded-md border border-input bg-background px-3 text-sm outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-primary focus:ring-2 focus:ring-primary/10";
  return <form onSubmit={(e) => {
    e.preventDefault();
    if (!name.trim() || !train.trim() || !origin.trim() || !destination.trim() || !age || ageN < 0 || ageN > 120) { toast.error("Please fill all fields correctly"); return; }
    const { state, passenger } = book(getState(), { name: name.trim(), age: ageN, train: train.trim(), origin: origin.trim(), destination: destination.trim(), disabled });
    setState(state);
    toast.success(passenger.status === "CONFIRMED" ? `Confirmed! Seat ${passenger.seat}` : "Added to waiting list", { description: `PNR ${passenger.pnr} · ${passenger.origin} → ${passenger.destination} · Rs.${passenger.fare}` });
    setName(""); setAge(""); setTrain(""); setOrigin(""); setDestination(""); setDisabled(false);
  }} className="self-start rounded-lg border border-border bg-card">
    <div className="flex items-center gap-3 border-b border-border px-5 py-4"><span className="flex size-8 items-center justify-center rounded-md bg-primary/10 text-primary"><Plus className="size-4" /></span><h2 className="text-base font-semibold">Book a ticket</h2></div>
    <div className="space-y-5 p-5">
      <fieldset className="space-y-4"><legend className="mb-3 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Passenger details</legend>
        <label className="block text-xs font-medium">Passenger name<input className={field} aria-label="Passenger name" required placeholder="Full name" value={name} onChange={(e) => setName(e.target.value)} /></label>
        <div className="grid grid-cols-2 gap-3"><label className="text-xs font-medium">Age<input className={field} type="number" aria-label="Age" required min={0} max={120} placeholder="Years" value={age} onChange={(e) => setAge(e.target.value)} /></label><label className="text-xs font-medium">Train number<input className={field} aria-label="Train number" required placeholder="e.g. 12001" value={train} onChange={(e) => setTrain(e.target.value)} /></label></div>
      </fieldset>
      <fieldset className="space-y-3 border-t border-border pt-4"><legend className="flex items-center gap-1.5 pr-2 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground"><RouteIcon className="size-3" /> Journey</legend>
        <label htmlFor="origin" className="block text-xs font-medium">Travel origin<input id="origin" className={field} required placeholder="Departure city or station" value={origin} onChange={(e) => setOrigin(e.target.value)} /></label>
        <label htmlFor="destination" className="block text-xs font-medium">Travel destination<input id="destination" className={field} required placeholder="Destination city or station" value={destination} onChange={(e) => setDestination(e.target.value)} /></label>
      </fieldset>
      <label className="flex cursor-pointer items-center justify-between gap-3 rounded-md bg-secondary/50 px-3 py-3"><span className="flex items-center gap-2 text-xs"><Accessibility className="size-4 shrink-0 text-accent" />Disabled / special passenger</span><Switch aria-label="Disabled / special passenger" checked={disabled} onCheckedChange={setDisabled} /></label>
      <div className="flex items-center justify-between gap-3 border-t border-border pt-4"><div><div className="text-xs font-medium">Final ticket fare</div>{age && ageN >= 0 && ageN <= 120 && <div className="mt-1 text-[11px] text-muted-foreground">{ageN >= 60 ? "Senior" : ageN < 10 ? "Child" : "Standard"}</div>}</div><output aria-label="Final ticket fare" aria-live="polite" className="font-mono text-xl font-semibold text-primary">{age && ageN >= 0 && ageN <= 120 ? `Rs.${computeFare(ageN)}` : "—"}</output></div>
      <Button type="submit" className="h-11 w-full justify-between px-4" size="lg"><span>Book Now</span><ArrowRight /></Button>
    </div>
  </form>;
}
